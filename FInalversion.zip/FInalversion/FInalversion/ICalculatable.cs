﻿using System;
namespace FinalVersion
{
    public class ICalculatable
    {
        public void CalculateValues(Expression input)
        {
           
        }
    }
}
