// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;

namespace FinalVersion
{
    [Register ("ViewController")]
    partial class ViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIButton btnadd { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITableView FormulaTable { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel lb1 { get; set; }

        [Action ("Btnadd_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void Btnadd_TouchUpInside (UIKit.UIButton sender);

        [Action ("UIButton17067_TouchUpInside:")]
        [GeneratedCode ("iOS Designer", "1.0")]
        partial void UIButton17067_TouchUpInside (UIKit.UIButton sender);

        void ReleaseDesignerOutlets ()
        {
            if (btnadd != null) {
                btnadd.Dispose ();
                btnadd = null;
            }

            if (FormulaTable != null) {
                FormulaTable.Dispose ();
                FormulaTable = null;
            }

            if (lb1 != null) {
                lb1.Dispose ();
                lb1 = null;
            }
        }
    }
}