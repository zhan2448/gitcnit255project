﻿using System;
namespace FinalVersion
{
    public class Specific_Number : Expression
    {
        public Specific_Number() : base("Specific Number", "x", "s")
        {
        }
    }
}